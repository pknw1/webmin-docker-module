Module to learn Webmin Modules 
